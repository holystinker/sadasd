<?php
session_start();
require_once("kapcsolat.php"); // Kapcsolat az adatbázishoz

// Ellenőrizzük, hogy a felhasználó be van-e jelentkezve
if (!isset($_SESSION['username'])) {
    die("Hiba: Nincs bejelentkezve!");
}

$uname = $_SESSION['username'];

// Előre meghatározott itemek és azok ára
$items = [
    'fast_fishing' => 100,
    'xp_boost' => 150,
    'double_fish' => 200,
    'better_rod' => 250,
    'slow_kapas_bar' => 300,
    'skin_placeholder' => 500
];

// Ellenőrizzük, hogy van-e POST kérés
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item = $_POST['item']; // Vásárolt tárgy neve

    // Ellenőrizzük, hogy létezik-e a tárgy az előre meghatározott listában
    if (!isset($items[$item])) {
        die("Hiba: Érvénytelen tárgy!");
    }

    $price = $items[$item];
    
    // Lekérdezzük a felhasználó egyenlegét
    $stmt = $conn->prepare("SELECT money FROM users WHERE Uname = ?");
    $stmt->bind_param("s", $uname);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if (!$user || $user['money'] < $price) {
        die("Hiba: Nincs elég pénzed!");
    }
    
    // Levonjuk az árat az egyenlegből
    $new_balance = $user['money'] - $price;
    $stmt = $conn->prepare("UPDATE users SET money = ? WHERE Uname = ?");
    $stmt->bind_param("is", $new_balance, $uname);
    $stmt->execute();
    
    // Itt lehetne menteni az adott boost vagy fejlesztés hatását az adatbázisba, ha szükséges
    
    echo "Sikeres vásárlás!";
}
?>