<?php
session_start();
require_once("kapcsolat.php");

header('Content-Type: application/json');

if (!isset($_SESSION['username'])) {
    echo json_encode(["error" => "Hiba: Be kell jelentkezned!"]);
    exit;
}

$uname = $_SESSION['username'];
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['item'], $data['price'])) {
    echo json_encode(["error" => "Hiányzó adatok."]);
    exit;
}

$itemName = $data['item'];
$price = (int)$data['price'];

$conn = new mysqli("localhost", "root", "", "fishygame");
if ($conn->connect_error) {
    echo json_encode(["error" => "Adatbázis kapcsolati hiba."]);
    exit;
}

// Ellenőrizzük a felhasználó érméit
$stmt = $conn->prepare("SELECT coins FROM users WHERE Uname = ?");
$stmt->bind_param("s", $uname);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    if ($row['coins'] < $price) {
        echo json_encode(["error" => "Nincs elég érméd a vásárláshoz."]);
        exit;
    }
}
$stmt->close();

// Levonjuk az érméket
$stmt = $conn->prepare("UPDATE users SET coins = coins - ? WHERE Uname = ?");
$stmt->bind_param("is", $price, $uname);
$stmt->execute();
$stmt->close();

// Hozzáadjuk a tárgyat az inventoryhoz
$stmt = $conn->prepare("INSERT INTO user_items (Uname, ItemName) VALUES (?, ?) ON DUPLICATE KEY UPDATE Quantity = Quantity + 1");
$stmt->bind_param("ss", $uname, $itemName);
$stmt->execute();
$stmt->close();

$conn->close();
echo json_encode(["message" => "Sikeresen megvásároltad a(z) $itemName tárgyat!"]);
?>