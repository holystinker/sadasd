<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once("kapcsolat.php");
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if(isset($_GET["Type"])) {
        $Type = $_GET["Type"];
        $sql = "SELECT *
                FROM fishes
                WHERE fishes.Type LIKE '%$Type%';";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0)
        {
            $halak_json = [];
            while($row = mysqli_fetch_assoc($result)){
                $halak_json[] = $row;
            }
            header("Content-Type: application/json");
            echo json_encode($halak_json);
        }
    }
}
elseif ($_SERVER['REQUEST_METHOD'] === 'POST')
{
    if(isset($_GET['FishName']))
    {
        $uname = $_SESSION['username'];
        $fishname = $_GET['FishName'];

        $sql = "SELECT *
                FROM fishbag
                WHERE fishbag.Uname LIKE '$uname' AND fishbag.FishName LIKE '$fishname';";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0)
        {
            $row = mysqli_fetch_assoc($result);
            $quantity = $row['Quantity'] + 1;
            $sql = "UPDATE fishbag 
                    SET fishbag.Quantity = $quantity
                    WHERE fishbag.Uname LIKE '$uname' AND fishbag.FishName LIKE '$fishname';";
            $result = mysqli_query($conn, $sql);
            if($result)
            {
                header("Content-Type: application/json");
            }
            else
            {
                http_response_code(404);
            }
        }
        else
        {            
            $sql = "INSERT INTO fishbag(Uname, FishName, Quantity)
                    VALUES ('$uname','$fishname', 1);";
            $result = mysqli_query($conn, $sql);
            if($result)
            {
                header("Content-Type: application/json");
            }
            else
            {
                http_response_code(404);
            }
        }        
    }
    else
    {
        http_response_code(404);
    }
}