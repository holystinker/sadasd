<?php
session_start();
require_once("kapcsolat.php");

header('Content-Type: application/json');

if (!isset($_SESSION['username'])) {
    echo json_encode(["error" => "Hiba: Be kell jelentkezned!"]);
    exit;
}

$uname = $_SESSION['username'];
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['fishList']) || empty($data['fishList'])) {
    echo json_encode(["error" => "Nincs kiválasztott hal."]);
    exit;
}

$conn = new mysqli("localhost", "root", "", "fishygame");
if ($conn->connect_error) {
    echo json_encode(["error" => "Adatbázis kapcsolati hiba."]);
    exit;
}

$totalEarnings = 0;
foreach ($data['fishList'] as $fish) {
    $fishName = $fish['fishName'];
    $quantityToSell = $fish['quantity'];

    // Ellenőrizzük, hogy a felhasználónak van-e elegendő hal
    $stmt = $conn->prepare("SELECT Quantity FROM fishbag WHERE Uname = ? AND FishName = ?");
    $stmt->bind_param("ss", $uname, $fishName);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $quantityInBag = $row['Quantity'];

        // Ha a felhasználónak nincs elegendő hal
        if ($quantityInBag < $quantityToSell) {
            echo json_encode(["error" => "Nincs elég $fishName a hal tárolóban."]);
            exit;
        }

        // Hal árának lekérése
        $stmt = $conn->prepare("SELECT Price FROM fishes WHERE FishName = ?");
        $stmt->bind_param("s", $fishName);
        $stmt->execute();
        $priceResult = $stmt->get_result();
        if ($priceRow = $priceResult->fetch_assoc()) {
            $totalEarnings += $priceRow['Price'] * $quantityToSell;
        }
        $stmt->close();

        // Halak törlése a fishbag-ból
        $stmt = $conn->prepare("UPDATE fishbag SET Quantity = Quantity - ? WHERE Uname = ? AND FishName = ?");
        $stmt->bind_param("iss", $quantityToSell, $uname, $fishName);
        $stmt->execute();
        $stmt->close();

        // Ha a hal mennyisége 0, töröljük a rekordot
        if ($quantityInBag - $quantityToSell == 0) {
            $stmt = $conn->prepare("DELETE FROM fishbag WHERE Uname = ? AND FishName = ?");
            $stmt->bind_param("ss", $uname, $fishName);
            $stmt->execute();
            $stmt->close();
        }
    } else {
        echo json_encode(["error" => "Nem található a hal a tárolódban: $fishName."]);
        exit;
    }
}

// Érmék hozzáadása
$stmt = $conn->prepare("UPDATE users SET Cash = Cash + ? WHERE Uname = ?");
$stmt->bind_param("is", $totalEarnings, $uname);
$stmt->execute();
$stmt->close();

$conn->close();
echo json_encode(["message" => "Sikeres eladás! Kaptál $totalEarnings érmét."]);
?>
