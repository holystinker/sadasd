<?php
session_start();
require_once("kapcsolat.php");

$beirtJelszo = '123';
$hashDbBol = '$2y$10$HlxEAW69jr9MtD0XmnJgyOQau';

if (password_verify($beirtJelszo, $hashDbBol)) {
    echo "Jelszó helyes!";
} else {
    echo "Jelszó hibás!";
}
?>