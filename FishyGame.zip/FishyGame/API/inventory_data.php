<?php

session_start();

ini_set('log_errors', 1);
ini_set('error_log', '/var/www/html/php_errors.log');
error_reporting(E_ALL);

require_once("kapcsolat.php"); // Adatbázis kapcsolat

header('Content-Type: application/json');

if (!isset($_SESSION['username'])) {
    echo json_encode(["error" => "Hiba: Be kell jelentkezned!"]);
    exit;
}

$uname = $_SESSION['username'];

// Adatbázis kapcsolat létrehozása
$conn = mysqli_connect("localhost", "root", "", "fishygame");

if (!$conn) {
    echo json_encode(["error" => "Adatbázis kapcsolódási hiba: " . mysqli_connect_error()]);
    exit;
}
if(isset($_GET['order'], $_GET['abc']))
{
    $order = $_GET['order'];
    $abc = $_GET['abc'];
    $sql = "SELECT fishes.FishName, fishes.Url, fishes.Rarity, fishes.Type, fishes.Price, fishes.Weight, fishbag.Quantity
        FROM fishes, fishbag
        WHERE fishes.FishName = fishbag.FishName and fishbag.Uname = ?
        ORDER BY fishes.$order $abc;";
}
else {
    $sql = "SELECT fishes.FishName, fishes.Url, fishes.Rarity, fishes.Type, fishes.Price, fishes.Weight, fishbag.Quantity
            FROM fishes, fishbag
            WHERE fishes.FishName = fishbag.FishName and fishbag.Uname = ?";
}



$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $uname);
$stmt->execute();
$result = $stmt->get_result();

$fishData = [];
while ($row = $result->fetch_assoc()) {
    $fishData[] = $row;
}

$stmt->close();
$conn->close();

// Ha nincs találat, akkor üzenet
if (empty($fishData)) {
    echo json_encode(["message" => "Még nincs kifogott hal!"]);
} else {
    echo json_encode($fishData);
}
?>
