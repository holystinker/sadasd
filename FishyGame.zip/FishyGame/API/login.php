<?php
session_start(); // Session indítása

error_reporting(E_ALL);
ini_set('display_errors', 1);


require_once("kapcsolat.php");

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["uzenet" => "Csak POST kéréseket fogadunk"]);
    exit();
}

if (!isset($_POST['email'], $_POST['password'])) {
    echo json_encode(["uzenet" => "Hiányzó adatok"]);
    exit();
}

$email = $_POST['email'];
$password = $_POST['password'];

$query = "SELECT Uname, Psw FROM users WHERE Email = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$result) {
    echo json_encode(["uzenet" => "Hiba a lekérdezésben: " . mysqli_error($conn)]);
    exit();
}

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);

    // Debug: Ellenőrizzük, hogy mit kapunk az adatbázisból
    error_log("Beírt jelszó: " . $password);
    error_log("Hash az adatbázisból: " . $row['Psw']);

    if (password_verify($password, $row['Psw'])) {  
        $_SESSION['username'] = $row['Uname']; // Bejelentkezett felhasználó mentése
        echo json_encode(["uzenet" => "Sikeres bejelentkezés"]);
    } else {
        echo json_encode(["uzenet" => "Helytelen jelszó"]);
    }
} else {
    echo json_encode(["uzenet" => "Felhasználó nem található"]);
}
mysqli_close($conn);
?>
