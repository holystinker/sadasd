<?php
// Engedélyezett hibák naplózása, de nem jelenítjük meg a böngészőben
error_reporting(E_ALL);  // Minden hiba naplózása
ini_set('display_errors', 1);  // Ne jelenjenek meg a hibák a böngészőben

session_start();
require_once("kapcsolat.php");

header('Content-Type: application/json');

// Csak POST kérés engedélyezése
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["uzenet" => "Csak POST kéréseket fogadunk"]);
    exit();
}

// Hiányzó adatokat ellenőrzés
if (!isset($_POST['email']) || !isset($_POST['password']) || !isset($_POST['username'])) {
    echo json_encode(["uzenet" => "Hiányzó adatok"]);
    exit();
}

$email = trim($_POST['email']);
$password = trim($_POST['password']);
$username = trim($_POST['username']);

// Ellenőrizzük, hogy az email már létezik-e
$query = "SELECT Email FROM users WHERE Email = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    echo json_encode(["uzenet" => "Ez az e-mail már regisztrálva van"]);
    exit();
}

// Megkeressük a legnagyobb Uname értéket és növeljük 1-gyel
$query = "SELECT MAX(Uname) AS max_uname FROM users";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo json_encode(["uzenet" => "Hiba a lekérdezésben"]);
    exit();
}

$row = mysqli_fetch_assoc($result);
$newUname = isset($row['max_uname']) ? $row['max_uname'] + 1 : 1; // Ha NULL, akkor 1 lesz

// Jelszó biztonságos hash-elése
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Új felhasználó regisztrálása
$query = "INSERT INTO users (Uname, Felhasznalo, Email, Psw, Lvl, Cash, Xp) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $query);

if (!$stmt) {
    echo json_encode(["uzenet" => "SQL hiba"]);
    exit();
}

$level = 1;
$money = 0;
$xp = 0;
mysqli_stmt_bind_param($stmt, "isssiii", $newUname, $username, $email, $hashedPassword, $level, $money, $xp);

if (mysqli_stmt_execute($stmt)) {
    $_SESSION['username'] = $username; // Automatikus bejelentkezés regisztráció után
    echo json_encode(["uzenet" => "Sikeres regisztráció"]);
} else {
    echo json_encode(["uzenet" => "Hiba történt a regisztráció során"]);
}

mysqli_close($conn);
?>
