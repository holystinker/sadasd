<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once("kapcsolat.php");
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $uname = $_SESSION["username"];
    $sql = "SELECT *
            FROM users
            WHERE users.Uname LIKE '$uname';";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) > 0)
    {
        $felhasznalo_json;
        $row = mysqli_fetch_assoc($result);
        $felhasznalo_json = $row;
        header("Content-Type: application/json");
        echo json_encode($felhasznalo_json);
    }
}
elseif ($_SERVER['REQUEST_METHOD'] === 'POST')
{
    if(isset($_GET['Xp']))
    {
        $uname = $_SESSION['username'];
        $xp = $_GET['Xp'];
        if($xp < 50)
        {
            $sql = "UPDATE users 
                    SET users.Xp = $xp
                    WHERE users.Uname LIKE '$uname';";
            $result = mysqli_query($conn, $sql);
            if($result)
            {
                header("Content-Type: application/json");
                http_response_code(200);
            }
            else
            {
                http_response_code(404);
            } 
        }
        else
        {
            $sql = "SELECT users.Lvl
                    FROM users
                    WHERE users.Uname LIKE '$uname';";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_assoc($result);
            $lvl = $row['Lvl'] + 1;
            $xp = $xp - 50;
            $sql = "UPDATE users 
                    SET users.Xp = $xp, users.Lvl = $lvl
                    WHERE users.Uname LIKE '$uname';";
            $result = mysqli_query($conn, $sql);
            if($result)
            {
                header("Content-Type: application/json");
                http_response_code(200);
            }
            else
            {
                http_response_code(404);
            }           
        }
    }
    else
    {
        http_response_code(404);
    }
}