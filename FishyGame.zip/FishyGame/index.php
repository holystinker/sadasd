<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
$parsed = parse_url($_SERVER["REQUEST_URI"]);
$path = $parsed["path"];

switch($path)
{
    case '/FishyGame/homepage':
        session_destroy();
        require_once("./views/login.html");
        break;
    case '/FishyGame/game':
        if (!empty($_SESSION['username']))
        {
            require_once("./views/jatek.html");
        }    
        else
        {
            header("Location: homepage");
            require_once("./views/login.html");
        }    
        break;
    case '/FishyGame/inventory':
        if (!empty($_SESSION['username']))
        {
            require_once("./views/inventory.html");
        }    
        else
        {
            header("Location: homepage");
            require_once("./views/login.html");
        }    
        break;
    case '/FishyGame/shop':
        if (!empty($_SESSION['username']))
        {
            require_once("./views/bolt.html");
        }    
        else
        {
            header("Location: homepage");
            require_once("./views/login.html");
        }    
        break;
    case '/FishyGame/shop2':
         if (!empty($_SESSION['username']))
        {
            require_once("./views/shop_inventory.html");
        }    
        else
        {
            header("Location: homepage");
            require_once("./views/login.html");
        }    
        break;
    case '/FishyGame/registration':
        require_once("./views/registration.html");
        break;
    default:
        echo "Az oldal nem jeleníthető meg " . "<a href='/FishyGame/homepage'>ugrás a bejelentkezéshez</a>";
        break;
}