let order_abc;
function call(order, abc)
{
    document.getElementById('fishTable').innerHTML = `
    <thead>
        <tr>
            <th>Hal Kép</th>
            <th onclick="ordering('FishName')">Hal Név</th>
            <th>Menynyiség</th>
            <th onclick="ordering('Rarity')">Ritkaság</th>
            <th onclick="ordering('Type')">Típus</th>
            <th onclick="ordering('Price')">Ár</th>
            <th onclick="ordering('Weight')">Súly</th>
        </tr>
        </thead>`;
    fetch(`/FishyGame/API/inventory_data.php?order=${order}&abc=${abc}`)
    .then(response => {
        // Ellenőrizzük, hogy a válasz jó-e
        if (!response.ok) {
            console.error("Hiba a hálózati kérésben: ", response.statusText);
            throw new Error("Hálózati hiba");
        }
        return response.json();
    })
    .then(data => {
        table = document.getElementById('fishTable');

        if (data.error) {
            console.log("Hiba történt a PHP oldalon:", data.error);
            alert(data.error);
            return;
        }

        // Ellenőrizzük, hogy üres-e az adatsor
        if (data.length === 0) {
            const row = table.insertRow();
            const cell = row.insertCell();
            cell.colSpan = 7;
            cell.textContent = "Még nem fogtál ki egy halat sem.";
        } else {
            data.forEach(fish => {
                const row = table.insertRow();

                const imgCell = row.insertCell();
                const img = document.createElement("img");
                img.src = fish.Url;  // URL-t kell használnunk
                img.alt = fish.FishName;
                img.style.width = '50px';
                img.style.height = '50px';
                imgCell.appendChild(img);

                row.insertCell().textContent = fish.FishName;
                row.insertCell().textContent = fish.Quantity;
                switch (fish.Rarity) {
                    case 1:
                        row.insertCell().textContent = "gyakori";
                        break;
                    case 2:
                        row.insertCell().textContent = "ritka";
                        break;
                    case 3:
                        row.insertCell().textContent = "legendás";
                        break;
                    default:
                        row.insertCell().textContent = "HIBA"
                        break;
                }
                row.insertCell().textContent = fish.Type;
                row.insertCell().textContent = fish.Price + " Érme";
                row.insertCell().textContent = fish.Weight + " kg";
            });
        }
    })
    .catch(error => {
        console.error('Hiba:', error);  // Hibák megjelenítése a konzolon
    });
}
call('FishName', 'ASC');
function ordering(order)
{
    if(order_abc == order)
    {
        order_abc = '';
        call(order, 'DESC');
    }
    else{
        order_abc = order;
        call(order, 'ASC');
    }
    
}