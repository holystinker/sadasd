document.getElementById("regisztracioForm").addEventListener("submit", function (event) {
    event.preventDefault(); // Megakadályozza az oldal újratöltését

    var adatok = new FormData(this);

    fetch('/FishyGame/API/registration.php', {
        method: 'POST',
        body: adatok
    })
    .then(response => response.json())
    .then(data => {
        alert(data.uzenet);
        if (data.uzenet === "Sikeres regisztráció") {
            window.location.href = "/FishyGame/homepage";
        }
    })
    .catch(error => console.error("Hiba:", error));
});