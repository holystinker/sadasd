document.addEventListener("DOMContentLoaded", function () {
    const menuToggle = document.getElementById("menu-toggle");
    const sidebar = document.getElementById("sidebarL");

    menuToggle.addEventListener("click", function () {
        sidebar.classList.toggle("open");
    });
});