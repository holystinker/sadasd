document.getElementById("bejelentkezesForm").addEventListener("submit", function (event) {
    event.preventDefault(); // Ne töltse újra az oldalt

    var adatok = new FormData(this); // Az űrlap adatai

    fetch('/FishyGame/API/login.php', { // URL ellenőrzése!
        method: 'POST',
        body: adatok
    })
    .then(response => response.json())
    .then(data => {
        alert(data.uzenet); // Megjeleníti az üzenetet
        if (data.uzenet === "Sikeres bejelentkezés") {
            window.location.href = "/FishyGame/game";
        }
    })
    .catch(error => console.error("Hiba:", error));
});