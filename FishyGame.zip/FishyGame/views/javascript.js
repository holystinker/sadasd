let van_e_kapas = false;
let sikeres_kapas = false;
let nyil_mozgas_jobbra = true;
let nyil_helye = -50;
let bar_allapot;
let bar_num;
var lifes = 4;
const bars = ['012', '102', '201', '210'];
let map = "Freshwater";
let halak;
let hal;
let felhasznalo;

window.onload = game_start()

function adatok_letolt() {
    fetch(`API/felhasznalo.php`)
        .then(adat => adat.json())
        .then(felhasznalo_json => {
            felhasznalo = felhasznalo_json;
            document.getElementById('adatok').innerHTML =
                `<li>Név: ${felhasznalo.Felhasznalo}</li>
                <li>Pénz: ${felhasznalo.Cash}</li>
                <li>Szint: ${felhasznalo.Lvl}</li>
                <li>Xp: ${felhasznalo.Xp}</li>`
        });
}
adatok_letolt()
function adatok_feltolt(xp) {
    fetch(`API/felhasznalo.php?Xp=${xp}`, { method: 'POST' })
        .then(valasz => {
            if (!valasz.ok) {
                console.log(valasz.json());
            }
            else {
                console.log("Sikeres adat frissítés!");
            }
        })
}

function game_start() {
    let seconds_to_wait = getrandomnumber(3000, 6000);
    setTimeout(function () {
        kapas_van();
    }, seconds_to_wait)
}

function getrandomnumber(min, max) {
    return Math.floor(Math.random() * (max - min) + min)
}

function kapas_van() {
    //document.body.style.backgroundImage = "url('./jatek_elemek/map_1_v2_map.gif')";
    document.getElementById("fisher").src = "jatek_elemek/fisher_night_catching.gif";
    van_e_kapas = true;
    renderBar();
    nyil_helye = -50;
    nyil_mozgas_jobbra = true;
    hal_random();
    Bar_mozgas(nyil_helye);
}

function renderBar() {
    bar_num = Math.floor(getrandomnumber(0, 4));
    document.getElementById("barDiv").innerHTML = `
    <div id="bar">
    <img id="scroll_bar" src="./jatek_elemek/${bar_num}.png" alt="">
    <img id="arrow" src="./jatek_elemek/arrow.png" alt="">
    </div>         
    `
}

function Bar_mozgas(i) {
    setTimeout(function () {
        document.getElementById("arrow").style.left = i + '%';
        if (i >= 50) {
            nyil_mozgas_jobbra = false;
        }
        if (i <= -50) {
            lifes--;
            //console.log("Life left: ", lifes);
            nyil_mozgas_jobbra = true;
        }
        if (nyil_mozgas_jobbra) {
            i += 1;
        }
        else {
            i -= 1;
        }
        if (i >= -50 && i <= -31 || i <= 50 && i >= 31) {
            bar_allapot = String(bars[Number(bar_num)])[0];
        }
        if (i >= -30 && i <= -11 || i <= 30 && i >= 11) {
            bar_allapot = String(bars[Number(bar_num)])[1];
        }
        if (i >= -10 && i <= 10) {
            bar_allapot = String(bars[Number(bar_num)])[2];
        }
        //console.log("Itt:", bar_allapot)
        if (lifes == 0) {
            bar_allapot == 0;
            sikeres_kapas = false;
            catchFish();
        }
        if (van_e_kapas) {
            Bar_mozgas(i);
        }
    }, 2)
}

function catchFish() {

    van_e_kapas = false;
    document.getElementById("fisher").src = "jatek_elemek/fisher_night_calm.gif";
    //document.body.style.backgroundImage = "url('./jatek_elemek/map_1_v2_map.gif')";
    if (sikeres_kapas) {
        document.getElementById("h1").innerHTML = `+${hal.FishName}<img src="${hal.Url}">`;
        //adatok_feltolt(felhasznalo);
        hal_feltolt(hal.FishName);
        let xp = Number(felhasznalo.Xp) + Number(hal.Rarity);
        adatok_feltolt(xp);
        adatok_letolt();
    }
    else {
        document.getElementById("h1").innerHTML = `A hal elúszott`;
    }
    document.getElementById("barDiv").innerHTML = '';
    lifes = 4;
    game_start();
}

document.addEventListener("keydown", (event) => {
    if (event.code === 'Space' && van_e_kapas) {
        switch (bar_allapot) {
            case '0':
                sikeres_kapas = false;
                break;
            case '1':
                sikeres_kapas = Math.random() < 0.5 ? false : true;
                break;
            case '2':
                sikeres_kapas = true;
                break;
        }
        catchFish();
    }
})

function hal_letolt() {
    fetch(`API/fishes.php?Type=${map}`)
        .then(adat => adat.json())
        .then(halak_json => {
            halak = halak_json;
            //console.log(halak.length);
            //console.log(halak);
        });
}
function hal_feltolt(fishname) {
    fetch(`API/fishes.php?FishName=${fishname}`, { method: 'POST' })
        .then(valasz => {
            if (!valasz.ok) {
                console.log(valasz.json());
            }
        })
}

function hal_random() {
    let ran_num = getrandomnumber(1, 11);
    let rarity;
    if (ran_num < 7) {
        rarity = 1;
    }
    if (ran_num >= 7 && ran_num < 10) {
        rarity = 2;
    }
    if (ran_num >= 10) {
        rarity = 3;
    }
    let halak2 = [];
    for (let item of halak) {
        if (item.Rarity == rarity) {
            halak2.push(item);
        }
    }
    //console.log(halak2.length);
    //console.log(halak2);
    let hal_id = getrandomnumber(0, halak2.length);
    hal = halak2[hal_id];
    //console.log(hal);
}

document.addEventListener("DOMContentLoaded", function () {
    const menuToggle = document.getElementById("menu-toggle");
    const sidebar = document.getElementById("sidebarL");

    menuToggle.addEventListener("click", function () {
        sidebar.classList.toggle("open");
    });
});
hal_letolt();